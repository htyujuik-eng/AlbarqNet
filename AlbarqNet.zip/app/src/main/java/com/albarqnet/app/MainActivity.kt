package com.albarqnet.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Credentials
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

private val Navy = Color(0xFF071629)
private val Panel = Color(0xFF102B45)
private val Cyan = Color(0xFF45D5F5)
private val Muted = Color(0xFF9CB2C8)

data class RouterEntry(val name: String, val host: String, val port: String, val secure: Boolean = true)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AlbarqApp() }
    }
}

@Composable
fun AlbarqApp() {
    var selected by remember { mutableStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    val routers = remember { mutableStateListOf(
        RouterEntry("MikroTik L009 الرئيسي", "192.168.88.1", "443"),
        RouterEntry("راوتر المستقبل 1", "192.168.88.2", "443"),
        RouterEntry("راوتر المستقبل 2", "192.168.88.3", "443")
    ) }
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Cyan, background = Navy, surface = Panel,
            onPrimary = Navy, onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Navy,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Color.White) {
                    NavigationBarItem(selected == 0, { selected = 0 }, icon = { Icon(Icons.Default.Dashboard, null) }, label = { Text("الرئيسية") })
                    NavigationBarItem(selected == 1, { selected = 1 }, icon = { Icon(Icons.Default.Router, null) }, label = { Text("الراوترات") })
                    NavigationBarItem(selected == 2, { selected = 2 }, icon = { Icon(Icons.Default.People, null) }, label = { Text("المشتركون") })
                    NavigationBarItem(selected == 3, { selected = 3 }, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("الإعدادات") })
                }
            }
        ) { padding ->
            when (selected) {
                0 -> Dashboard(routers.size, Modifier.padding(padding))
                1 -> RouterScreen(routers, Modifier.padding(padding), { showAdd = true })
                2 -> SubscribersScreen(Modifier.padding(padding))
                else -> SettingsScreen(Modifier.padding(padding))
            }
        }
        if (showAdd) AddRouterDialog(
            onDismiss = { showAdd = false },
            onAdd = { name, host, port ->
                routers.add(RouterEntry(name, host, port))
                showAdd = false
            }
        )
    }
}

@Composable
fun Header() {
    Row(Modifier.fillMaxWidth().padding(bottom = 18.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("⚡ البرق نت", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("إدارة الشبكة الذكية", color = Cyan, fontSize = 13.sp)
        }
        Surface(color = Panel, shape = RoundedCornerShape(14.dp)) {
            Icon(Icons.Default.Bolt, null, tint = Cyan, modifier = Modifier.padding(12.dp).size(28.dp))
        }
    }
}

@Composable
fun Dashboard(routerCount: Int, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(18.dp)) {
        Header()
        Text("ملخص الشبكة", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
        Text("واجهة تجريبية — اربط الراوترات لعرض بياناتك الحقيقية", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp, bottom = 16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("المتصلون", "—", "users", Modifier.weight(1f))
            MetricCard("الراوترات", routerCount.toString(), "router", Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("سرعة التنزيل", "— Mbps", "download", Modifier.weight(1f))
            MetricCard("المعالج", "— %", "cpu", Modifier.weight(1f))
        }
        Spacer(Modifier.height(18.dp))
        Text("الوصول السريع", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(10.dp))
        QuickAction("إدارة أجهزة MikroTik", "إضافة راوتر أو فحص الاتصال", Icons.Default.Router)
        QuickAction("المستخدمون النشطون", "عرض جلسات Hotspot", Icons.Default.People)
        QuickAction("التقارير والمبيعات", "الكروت والإيرادات", Icons.Default.Assessment)
        Spacer(Modifier.weight(1f))
        Text("ALBARQ NET • الإصدار التجريبي 0.1.0", color = Muted, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
    }
}

@Composable
fun MetricCard(title: String, value: String, icon: String, modifier: Modifier = Modifier) {
    Surface(modifier, color = Panel, shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(15.dp)) {
            val image = when(icon) {
                "users" -> Icons.Default.People
                "router" -> Icons.Default.Router
                "download" -> Icons.Default.Download
                else -> Icons.Default.Memory
            }
            Icon(image, null, tint = Cyan, modifier = Modifier.size(23.dp))
            Spacer(Modifier.height(12.dp))
            Text(value, fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text(title, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
fun QuickAction(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Cyan, modifier = Modifier.size(26.dp))
            Column(Modifier.padding(start = 12.dp).weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.Medium)
                Text(subtitle, color = Muted, fontSize = 12.sp)
            }
            Icon(Icons.Default.ChevronLeft, null, tint = Muted)
        }
    }
}

@Composable
fun RouterScreen(routers: List<RouterEntry>, modifier: Modifier = Modifier, onAdd: () -> Unit) {
    Column(modifier.fillMaxSize().padding(18.dp)) {
        Header()
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("أجهزة MikroTik", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Button(onClick = onAdd) { Icon(Icons.Default.Add, null); Text("إضافة") }
        }
        Text("أضف عناوين الراوترات المحلية أو عناوين VPN الآمنة", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 10.dp))
        LazyColumn {
            items(routers) { router ->
                Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Router, null, tint = Cyan, modifier = Modifier.size(30.dp))
                        Column(Modifier.padding(start = 12.dp).weight(1f)) {
                            Text(router.name, color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text("${router.host}:${router.port}", color = Muted, fontSize = 12.sp)
                        }
                        Text("غير مربوط", color = Color(0xFFFFC36B), fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun SubscribersScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(18.dp)) {
        Header()
        Text("المشتركون النشطون", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Surface(color = Panel, shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp)) {
                Icon(Icons.Default.People, null, tint = Cyan, modifier = Modifier.size(32.dp))
                Spacer(Modifier.height(8.dp))
                Text("لا توجد بيانات متصلة بعد", color = Color.White, fontWeight = FontWeight.SemiBold)
                Text("ستظهر جلسات Hotspot بعد إعداد اتصال آمن بالراوتر.", color = Muted, fontSize = 13.sp)
            }
        }
    }
}

@Composable
fun SettingsScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(18.dp)) {
        Header()
        Text("الإعدادات والحماية", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        QuickAction("الاتصال البعيد", "استخدم VPN مثل WireGuard للوصول الآمن", Icons.Default.Security)
        QuickAction("حساب API محدود", "أنشئ مستخدماً بصلاحيات قراءة محدودة", Icons.Default.Key)
        QuickAction("حول التطبيق", "البرق نت — Android MVP 0.1.0", Icons.Default.Info)
    }
}

@Composable
fun AddRouterDialog(onDismiss: () -> Unit, onAdd: (String, String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var host by remember { mutableStateOf("") }
    var port by remember { mutableStateOf("443") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة راوتر") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("اسم الراوتر") }, singleLine = true)
                OutlinedTextField(host, { host = it }, label = { Text("عنوان IP أو VPN") }, singleLine = true)
                OutlinedTextField(port, { port = it }, label = { Text("منفذ HTTPS / REST") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                Text("لا تضع كلمة المرور هنا. ستُطلب عند تنفيذ الاتصال في مرحلة الربط.", color = Muted, fontSize = 11.sp)
            }
        },
        confirmButton = { TextButton(onClick = { if (name.isNotBlank() && host.isNotBlank() && port.toIntOrNull() != null) onAdd(name.trim(), host.trim(), port.trim()) }) { Text("إضافة") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

/**
 * RouterOS 7 REST client starter.
 * Use only over HTTPS with a valid certificate, preferably through WireGuard VPN.
 * Never disable certificate validation or expose the API directly to the public Internet.
 */
class RouterOsRestClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .build()

    suspend fun getSystemResource(baseUrl: String, username: String, password: String): String =
        withContext(Dispatchers.IO) {
            val request = Request.Builder()
                .url(baseUrl.trimEnd('/') + "/rest/system/resource")
                .header("Authorization", Credentials.basic(username, password))
                .get()
                .build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) error("RouterOS returned HTTP ${response.code}")
                response.body?.string() ?: "{}"
            }
        }
}
